﻿namespace InvestmentSystemToolkit.Service
{
    public interface IEnviromentService
    {
        bool VersionUpdate();


    }
}
