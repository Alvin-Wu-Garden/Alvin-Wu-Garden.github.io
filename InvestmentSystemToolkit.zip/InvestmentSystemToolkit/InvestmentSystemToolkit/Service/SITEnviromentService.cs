﻿using System;
using System.Diagnostics;
using System.Xml.Linq;
using Microsoft.SqlServer.TransactSql.ScriptDom;
using Microsoft.Web.Administration;

namespace InvestmentSystemToolkit.Service
{
    public class SITEnviromentService : IEnviromentService
    {



        public SITEnviromentService()
        {

        }


        public bool VersionUpdate()
        {


            








            string webConfigXmlPath = "./dsd/wdwdd/wen.config";
            if (File.Exists(webConfigXmlPath))
            {
                XDocument webConfigXml = XDocument.Load(webConfigXmlPath);

                IEnumerable<XElement> connectionStrings = webConfigXml.Element("connectionStrings").Elements("add");

            }
            return true;
        }






        public string  CloseAppicationPool()
        {

            ServerManager serverManager = new ServerManager();


           var siteStatus= serverManager.Sites.FirstOrDefault().Stop();

            string output = "";

            switch (siteStatus)
            {
                case ObjectState.Starting:
                    output = "運行中";
                    break;
                case ObjectState.Started:
                    output = "執行中";
                    break;
                case ObjectState.Stopping:
                    output = "正在停止";
                    break;
                case ObjectState.Stopped:
                    output = "已停止";
                    break;
                case ObjectState.Unknown:
                    output = "未知狀態";
                    break;
                default:
                    break;
            }


            //Process p = new Process();
            //ProcessStartInfo info = new ProcessStartInfo
            //{
            //    //WorkingDirectory= @"C:\Windows\System32\inetsrv\",
            //    FileName = @"cmd.exe",
            //    RedirectStandardInput = true,
            //    RedirectStandardOutput = true,
            //    LoadUserProfile = true,
            //    UseShellExecute = false,
            //    Verb = "runas"
            //};
            //p.StartInfo = info;
            //p.Start();


            //string siteName = "\"Default Web Site\"";


            //using (StreamWriter sw = p.StandardInput)
            //{
            //    if (sw.BaseStream.CanWrite)
            //    {
            //        sw.WriteLine(@$"%systemroot%\system32\inetsrv\APPCMD list sites");
            //        //sw.WriteLine(@$"CD C:\Windows\System32\cmd.exe LIST APPPOOL");
            //    }
            //}

            //string output = p.StandardOutput.ReadToEnd();



            

            return output;
        }
    }
}
