﻿using Microsoft.AspNetCore.Rewrite;
using Microsoft.SqlServer.TransactSql.ScriptDom;
using System.Runtime.Intrinsics.Arm;

namespace InvestmentSystemToolkit.Service
{
    public class SQLFormatter
    {
        private readonly TSqlFragment sqlFragment;

        public string RewriteContext { get; set; }
        public SQLFormatter (TSqlFragment sqlFragment) {
            this.sqlFragment = sqlFragment;
        }




        public void ReplaceNoLockToWithNoLock() 
        {
            string aa = "";
            int tokenIndex = 0;
            //foreach (var token in sqlFragment.ScriptTokenStream)
            //{
            //    tokenIndex += 1;
            //    if (token.TokenType == TSqlTokenType.Identifier && token.Text.ToUpper()=="NOLOCK")
            //    {
            //        //string previousTokenText = sqlFragment.ScriptTokenStream[tokenIndex-1].Text;
            //        //string firstTwoTimesTokenText = sqlFragment.ScriptTokenStream[tokenIndex - 2].Text;
            //        string firstThreeTimesTokenText = sqlFragment.ScriptTokenStream[tokenIndex - 3].Text;

            //        if ($"{firstThreeTimesTokenText}" != "WITH") 
            //        {
            //            sqlFragment.ScriptTokenStream.Insert(tokenIndex - 3, new TSqlParserToken(TSqlTokenType.With, "WITH"));
            //        }
            //        continue;
            //    }

            //    //token.TokenType= TSqlTokenType.no



            //    //output.Append(token.Text);
            //}

            var aaa = new List<TSqlParserToken>();

            for (int i = 0; i < sqlFragment.ScriptTokenStream.Count; i++)
            {

                if (sqlFragment.ScriptTokenStream[i].TokenType == TSqlTokenType.Identifier && sqlFragment.ScriptTokenStream[i].Text.ToUpper() == "NOLOCK")
                {
                    //string previousTokenText = sqlFragment.ScriptTokenStream[tokenIndex-1].Text;
                    //string firstTwoTimesTokenText = sqlFragment.ScriptTokenStream[tokenIndex - 2].Text;
                    string firstThreeTimesTokenText = sqlFragment.ScriptTokenStream[i-3].Text;

                    if ($"{firstThreeTimesTokenText}" != "WITH")
                    {
                        
                        aaa.Insert(i-1,new TSqlParserToken(TSqlTokenType.With, "WITH"));
                        aaa.Insert(i, new TSqlParserToken(TSqlTokenType.WhiteSpace, " "));
                    }
                    
                }

                aaa.Add(sqlFragment.ScriptTokenStream[i]);
            }





            //var formatter = new Sql120ScriptGenerator();

            //formatter.GenerateScript();

            SqlScriptGeneratorOptions sqlScriptGeneratorOptions = new SqlScriptGeneratorOptions
            {
                IncludeSemicolons = false,
                KeywordCasing = KeywordCasing.Uppercase,
                
                //MultilineInsertSourcesList = true
            };


            var formatter = new Sql120ScriptGenerator();

            formatter.GenerateScript(sqlFragment,out aa);




            aa = string.Join("", aaa.Select(x => x.Text).ToArray());


            //rdr.Close();
            //return Ok(output.ToString());


        }
    }
}
