using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Collections;
using System.IO;
using System.Net;
using System.Reflection.Metadata;
using System.Xml;
using System.Xml.Linq;

using System.Collections.Generic;

namespace InvestmentSystemToolkit.Pages.Deployment
{
    public class SITVersionUpdateModel : PageModel
    {

        public SITEnviromentInfomation SITEnviromentInfomation { get; set; }

        public void OnGet()
        {

            //Path.Combine
            string webConfigPath = @"G:\test\web.config";

            if (System.IO.File.Exists(webConfigPath))
            {
                XDocument webConfigXML = XDocument.Load(webConfigPath);

                string connectString= webConfigXML.Descendants("appSettings").Elements().FirstOrDefault( x =>x.Attribute("key").Value== "sqlConnection").Attribute("value").Value;


                SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectString);


                

                //var aa= new Comparer<ClassA>().Compare(new ClassA() { StringProperty = "dd", IntProperty = 123 }, new ClassA { StringProperty = "dd", IntProperty = 123 });

                //sqlConnectionStringBuilder.


















            }



            string hostName = Dns.GetHostName();

            var feature = HttpContext.Features.Get<IHttpConnectionFeature>();
            string ipAddress = feature.LocalIpAddress.ToString();

            SITEnviromentInfomation = new SITEnviromentInfomation()
            {
                IpAddress = ipAddress,
                HostName = hostName
            };
        }
    }

    public class SITEnviromentInfomation
    {
        public string IpAddress { get; set; }
        public string HostName { get; set; }

    }

    public class ClassA
    {
        public string StringProperty { get; set; }

        public int IntProperty { get; set; }

        //public SubClassA SubClass { get; set; }
    }
}
