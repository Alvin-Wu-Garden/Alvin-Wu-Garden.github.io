using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.Extensions.FileProviders;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Logging;
using InvestmentSystemToolkit.Controller;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddControllers();
builder.Services.AddSignalR();
builder.Services.AddSingleton<NotificationQueue>();



var app = builder.Build();
app.Urls.Add("http://127.0.0.1:3388");


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseFileServer(
new FileServerOptions
{
    RequestPath = "",
    FileProvider = new ManifestEmbeddedFileProvider(typeof(Program).Assembly, "wwwroot")
})
.UseFileServer(new FileServerOptions
{
    RequestPath = "/StaticFiles",
    FileProvider = new ManifestEmbeddedFileProvider(typeof(Program).Assembly, "StaticFiles"),
});



app.UseRouting();

app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapRazorPages();
    endpoints.MapControllerRoute("default", "api/{controller=Values}/{action=Index}/{id?}");
    endpoints.MapHub<NotificationHub>("/notificationhub");
    //endpoints.ma
});


var task = app.RunAsync();

if (!Debugger.IsAttached)
{
    var url = app.Services.GetRequiredService<IServer>()
        .Features.Get<IServerAddressesFeature>()!
            .Addresses.First();
    Process.Start(new ProcessStartInfo("cmd", $"/c start {url}")
    { CreateNoWindow = true });
}

task.Wait();
