﻿using InvestmentSystemToolkit.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;

namespace InvestmentSystemToolkit.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeploymentController : ControllerBase
    {


        [HttpGet]
        public IActionResult SystemIntegrationTestVersionUpdate()
        {
            bool aa = new SITRepository().VersionUpdate();
            return Ok(aa);
        }
    }
}
