﻿using InvestmentSystemToolkit.Repository;
using InvestmentSystemToolkit.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq.Expressions;
using System.Runtime.Intrinsics.Arm;
using System.Security.Principal;
using System.Text;

namespace InvestmentSystemToolkit.Controller
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly NotificationQueue _notificationQueue;
        public ValuesController(NotificationQueue notificationQueue)
        {
            _notificationQueue = notificationQueue;
        }





        [HttpGet]
        public IActionResult Index()
        {
            // bool haveCreate = false; 
            // var output = new StringBuilder();
            // IList<ParseError> errors;
            // StreamReader rdr = new StreamReader("C:\\Users\\Admin\\Desktop\\sql formmater\\test.sql");

            // var parser = new TSql160Parser(true, SqlEngineType.All);
            // var tree = parser.Parse(rdr, out errors);

            // new SQLFormatter(tree).ReplaceNoLockToWithNoLock();

            // //foreach (var token in tree.ScriptTokenStream)
            // //{
            // //    //if (!haveCreate && token.TokenType == TSqlTokenType.Select)
            // //    //{
            // //    //    var alterToken = new TSqlParserToken(TSqlTokenType.Alter, "ALTER");
            // //    //    output.Append(alterToken.Text);
            // //    //    haveCreate = true;
            // //    //    continue;
            // //    //}

            // //    //token.TokenType= TSqlTokenType.no



            // //    output.Append(token.Text);
            // //}

            // //rdr.Close();
            // return Ok(output.ToString());

            // SqlScriptGeneratorOptions sqlScriptGeneratorOptions = new SqlScriptGeneratorOptions();

            // sqlScriptGeneratorOptions.KeywordCasing = KeywordCasing.Uppercase;

            //return Ok(new SITEnviromentService().CloseAppicationPool());
            //using (StreamReader rdr = new StreamReader("C:\\Users\\Admin\\Desktop\\sql formmater\\SQLQuery1.sql"))
            //{

            //    IList<ParseError> errors;
            //    var parser = new TSql160Parser(true, SqlEngineType.All);
            //    var tree = parser.Parse(rdr, out errors);
            //    var visitor = new SelectVisitor();
            //    tree.Accept(visitor);
            //    return Ok(new SQLValidator(visitor).CheckStoredProcedureHasSETQUOTED_IDENTIFIERON());
            //}
            //    List<int> ss = new List<int>();

            //    List<string> sss = new List<string>();

            //    foreach (var item in visitor.NamedTableReferenceList)
            //    {

            //        foreach (var item2 in item.TableHints)
            //        {


            //            foreach (var item666 in item2.ScriptTokenStream)
            //            {
            //                //item666.TokenType.

            //                sss.Add(item666.Text);
            //            }


            //            if (item2.HintKind == TableHintKind.NoLock)
            //            {

            //                ss.Add(item2.StartLine);

            //            }
            //        }


            //    }
            //    var selectStatement = visitor.SelectStatements.FirstOrDefault();
            //    var specification = selectStatement.QueryExpression as QuerySpecification;


            //    var aa = specification.FromClause.ScriptTokenStream.FirstOrDefault();


            //    var cc = specification.FromClause.ScriptTokenStream.Select(x =>
            //    {

            //        if (x.TokenType == TSqlTokenType.Identifier && x.Text == "nolock")
            //        {
            //            return new
            //            {
            //                x.Line,
            //                x.Offset
            //            };
            //        }
            //        else
            //        {

            //            return new { Line = 1, Offset = 1 };
            //        }



            //    });




            //    var tableReference = specification.FromClause.TableReferences.FirstOrDefault() as NamedTableReference;

            //    Console.WriteLine(tableReference.SchemaObject.BaseIdentifier.Value);
            //}




            //string aaaaaaa = "ddd";


            //Expression<Func<Blog, bool>> aaaccaaaa = x => x.Url == aaaaaaa;







            //using var db = new BloggingContext();




            ////var ss = db.Blogs.Where(x => { 

            ////return x.Url == aaaaaaa;
            ////});


            //// db.Blogs.Where(new Expression<Func<Blog, bool>>(o=> {

            ////    var aaaa= new Blog
            ////     {
            ////         Url= o.Url
            ////     };
            ////return aaaa == aa;
            //// }


            ////));

            //return Ok(db.Blogs.OrderBy(b => b.BlogId).FirstOrDefault());
            _notificationQueue.Enqueue("123");
            _notificationQueue.Enqueue("456");
            _notificationQueue.Enqueue("789");
            _notificationQueue.Enqueue("101112");
            _notificationQueue.Enqueue("131415");

            return Ok(true);
        }


        [HttpGet]
        public IActionResult GetIPAddress()
        {
            string hostName = System.Net.Dns.GetHostName();

            var feature = HttpContext.Features.Get<IHttpConnectionFeature>();
            string ipAddress = feature?.LocalIpAddress?.ToString();

            return Ok(new
            {
                hostName,
                ipAddress
            });

        }

        private bool RelayMethod(Blog blog)
        {
            if (blog.Url == "ok")
                return true;

            return false;
        }

        public async Task ConnectSse()
        {





            Response.Headers.Add("Content-Type", "text/event-stream");

            //Response.Headers.Add("Content-Type", "text/event-stream");
            //Response.Headers.Add("Cache-Control", "no-cache");
            //Response.Headers.Add("Connection", "keep-alive");
            //while (true)
            //{
            //    await Response.WriteAsync($"data: Controller at {DateTime.Now}\r\r");
            //    await Response.Body.FlushAsync();
            //    CancellationToken cancellationToken = HttpContext.RequestAborted;
            //    if (cancellationToken.IsCancellationRequested)
            //    {
            //        return;
            //    }
            //    await Task.Delay(2000);
            //}

            foreach (var message in _notificationQueue.DequeueAll())
            {
                var data = $"data: {message}\n\n";
                await Response.WriteAsync(data);
                await Response.Body.FlushAsync();
            }
        }

    }


    public class SelectVisitor : TSqlConcreteFragmentVisitor
    {
        public List<SelectStatement> SelectStatements { get; private set; }

        public List<NamedTableReference> NamedTableReferenceList { get; private set; }

        public List<ProcedureReference> ProcedureReferenceList { get; private set; }





        public SelectVisitor()
        {
            NamedTableReferenceList = new List<NamedTableReference>();
            SelectStatements = new List<SelectStatement>();
            ProcedureReferenceList = new List<ProcedureReference>();
        }


        public override void ExplicitVisit(SelectStatement node)
        {
            base.ExplicitVisit(node);
            SelectStatements.Add(node);
        }

        public override void ExplicitVisit(NamedTableReference node)
        {
            base.ExplicitVisit(node);

            NamedTableReferenceList.Add(node);
        }

        public override void ExplicitVisit(ProcedureReference node)
        {
            base.ExplicitVisit(node);
            ProcedureReferenceList.Add(node);
        }
    }

    public class NotificationQueue
    {
        private readonly BlockingCollection<string> _queue = new BlockingCollection<string>();

        public void Enqueue(string message)
        {
            _queue.Add(message);
        }

        public IEnumerable<string> DequeueAll()
        {
            while (_queue.TryTake(out string message))
            {
                yield return message;
            }
        }
    }

    public class NotificationHub : Hub
    {
        private readonly NotificationQueue _notificationQueue;

        public NotificationHub(NotificationQueue notificationQueue)
        {
            _notificationQueue = notificationQueue;
        }

        public async Task SendMessage(string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", message);
            _notificationQueue.Enqueue(message);
        }
    }
}
