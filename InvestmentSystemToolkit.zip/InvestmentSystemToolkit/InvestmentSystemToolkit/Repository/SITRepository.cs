﻿using System.Xml;
using System.Xml.Linq;

namespace InvestmentSystemToolkit.Repository
{
    public class SITRepository
    {
        public SITRepository() { }

        public bool VersionUpdate() {

            string webConfigXmlPath = "./dsd/wdwdd/wen.config";
            if (File.Exists(webConfigXmlPath))
            {
                XDocument webConfigXml = XDocument.Load(webConfigXmlPath);

                IEnumerable<XElement> connectionStrings = webConfigXml.Element("connectionStrings").Elements("add");

            }
            return true;

        }
    }
}
