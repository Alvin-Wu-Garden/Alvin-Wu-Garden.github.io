﻿using InvestmentSystemToolkit.Controller;
using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace InvestmentSystemToolkit.Repository
{
    public class SQLValidator
    {
        public SelectVisitor SelectVisitor { get; private set; }

        public SQLValidator(SelectVisitor selectVisitor)
        {

            this.SelectVisitor = selectVisitor;
        }

        public bool CheckStoredProcedureHasSETQUOTED_IDENTIFIERON()
        {
            string validateString = "SET QUOTED_IDENTIFIER ON";
            bool dad=false;

            if (SelectVisitor.ProcedureReferenceList!=null && SelectVisitor.ProcedureReferenceList?.Count() > 0)
            {
                for (int i = 0; i < SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream.Count(); i++)
                {
                    if (i + 4 < SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream.Count()) {

                        if (SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i].TokenType == TSqlTokenType.Set &&
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i+1].TokenType == TSqlTokenType.WhiteSpace &&
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i+2].TokenType == TSqlTokenType.Identifier &&
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i+3].TokenType == TSqlTokenType.WhiteSpace &&
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i+4].TokenType == TSqlTokenType.On)
                        {

                            dad = SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i].Text +
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i + 1].Text +
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i + 2].Text +
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i + 3].Text +
                            SelectVisitor.ProcedureReferenceList.FirstOrDefault().ScriptTokenStream[i + 4].Text == validateString ? true : false;
                        }

                    }
                };


                return dad;
            }
            else
            {
                return false;
            }
        }
    }
}
